# restaurant-management
This project emphasizes on the use of advanced frontend technologies like html , css , js and many more , database postgres and express and node implemented together as backend
